#!/usr/bin/env python3
"""Validate a Refract JSON guide (Python standard library only)."""
import json, re, sys
def main(path):
    try:
        with open(path, encoding="utf-8") as f: d = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        print("Invalid JSON or unreadable file:", e); return 1
    errors = []
    if not isinstance(d, dict): return bad("JSON root must be an object")
    pages=d.get("pages")
    if not isinstance(pages,list) or not pages: return bad("pages must be a nonempty array")
    if not isinstance(d.get("meta"),dict) or not isinstance(d["meta"].get("title"),str): errors.append("meta.title must be a string")
    if not isinstance(d.get("glossary"),list): errors.append("glossary must be an array")
    types={"hero","paragraph","note","checks","cards","steps","bullets","table","resources","glossary"}
    ids=set()
    for i,p in enumerate(pages,1):
        prefix=f"Page {i}"
        if not isinstance(p,dict): errors.append(prefix+": must be an object"); continue
        pid=p.get("id")
        if not isinstance(pid,str) or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*",pid): errors.append(prefix+": invalid id")
        if pid in ids: errors.append(prefix+": duplicate id "+str(pid))
        ids.add(pid)
        if not isinstance(p.get("title"),str): errors.append(prefix+": missing title")
        blocks=p.get("blocks")
        if not isinstance(blocks,list): errors.append(prefix+": blocks must be an array"); continue
        for j,b in enumerate(blocks,1):
            path=f"{prefix}, block {j}"
            if not isinstance(b,dict) or b.get("type") not in types: errors.append(path+": invalid type");continue
            typ=b["type"]
            if typ=="note":
                if not isinstance(b.get("label"),str) or not isinstance(b.get("text"),str): errors.append(path+": note requires label and text")
            elif not isinstance(b.get("title"),str): errors.append(path+": block requires title")
            if typ in ("hero","paragraph") and not isinstance(b.get("text"),str):errors.append(path+": requires text")
            if typ=="table":
                cols,rows=b.get("columns"),b.get("rows")
                if not isinstance(cols,list) or not cols or not isinstance(rows,list): errors.append(path+": table requires columns and rows arrays")
                else:
                    for k,row in enumerate(rows,1):
                        if not isinstance(row,list) or len(row)!=len(cols): errors.append(path+f": row {k} has wrong cell count")
            if typ in ("checks","cards","steps","bullets","resources","glossary"):
                items=b.get("items")
                if not isinstance(items,list): errors.append(path+": items must be an array");continue
                for k,item in enumerate(items,1):
                    label=path+f", item {k}"
                    if typ=="bullets":
                        if not isinstance(item,str):errors.append(label+": must be a string")
                    elif not isinstance(item,dict): errors.append(label+": must be an object")
                    elif typ=="checks" and not all(isinstance(item.get(x),str) for x in ("title","detail")):errors.append(label+": checks need title and detail")
                    elif typ in ("cards","steps") and not all(isinstance(item.get(x),str) for x in ("title","text")):errors.append(label+": requires title and text")
                    elif typ=="resources" and not (isinstance(item.get("title"),str) and isinstance(item.get("url"),str) and item["url"].startswith(("https://","http://"))):errors.append(label+": resources need title and HTTP(S) URL")
                    elif typ=="glossary" and not all(isinstance(item.get(x),str) for x in ("term","definition")):errors.append(label+": glossary needs term and definition")
    for i,p in enumerate(pages,1):
        if not isinstance(p,dict):continue
        if p.get("parent") and p["parent"] not in ids:errors.append(f"Page {i}: unknown parent")
        for b in p.get("blocks",[]):
            if isinstance(b,dict) and b.get("type")=="cards":
                for card in b.get("items",[]):
                    if isinstance(card,dict) and card.get("link") and card["link"] not in ids:errors.append(f"Page {i}: unknown card destination")
    if errors:
        for error in errors:print("ERROR:",error)
        return 1
    print("VALID: "+str(len(pages))+" Refract pages");return 0
def bad(message):
    print("ERROR:",message);return 1
if __name__=="__main__":
    if len(sys.argv)!=2:sys.exit("Usage: python validate_refract.py guide.json")
    sys.exit(main(sys.argv[1]))

#!/usr/bin/env python3
import json,sys,re
try:
 d=json.load(open(sys.argv[1],encoding="utf-8"))
 assert isinstance(d.get("meta",{}).get("title"),str)
 pages=d["pages"];assert isinstance(pages,list) and pages
 ids=set()
 for p in pages:
  assert re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*",p["id"]) and p["id"] not in ids
  ids.add(p["id"])
 for p in pages:
  if p.get("parent"):assert p["parent"] in ids
  for b in p["blocks"]:
   t=b["type"]
   assert t in ("hero","paragraph","note","checks","cards","steps","bullets","table","resources","glossary")
   if t=="note":assert isinstance(b.get("label"),str)
   elif t!="note":assert isinstance(b.get("title"),str)
   if t=="table":assert all(len(r)==len(b["columns"]) for r in b["rows"])
   if t in ("checks","cards","steps","bullets","resources","glossary"):
    for x in b["items"]:
     if t=="bullets":assert isinstance(x,str)
     elif t=="checks":assert isinstance(x.get("title"),str) and isinstance(x.get("detail"),str)
     elif t in ("cards","steps"):assert isinstance(x.get("title"),str) and isinstance(x.get("text"),str)
     elif t=="resources":assert x.get("url","").startswith(("https://","http://"))
     elif t=="glossary":assert isinstance(x.get("term"),str) and isinstance(x.get("definition"),str)
     if t=="cards" and isinstance(x,dict) and x.get("link"):assert x["link"] in ids
 print("VALID")
except Exception as e:
 print("INVALID:",str(e));sys.exit(1)

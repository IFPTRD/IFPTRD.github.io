# Refract data model

Root: `{"meta":{"title":"...","subtitle":"...","audience":"..."},"pages":[...],"glossary":[]}`

Each page: `{"id":"unique-kebab-case","title":"Page","intro":"Optional","parent":"optional-existing-id","blocks":[...]}`

| Block | Structure |
| --- | --- |
| hero | `{"type":"hero","kicker":"...","title":"...","text":"..."}` |
| paragraph | `{"type":"paragraph","title":"...","text":"..."}` |
| note | `{"type":"note","label":"Important","text":"..."}` |
| checks | `{"type":"checks","title":"...","items":[{"title":"...","detail":"..."}]}` |
| cards | `{"type":"cards","title":"...","items":[{"title":"...","text":"...","link":"existing-page-id"}]}` |
| steps | `{"type":"steps","title":"...","items":[{"title":"...","text":"..."}]}` |
| bullets | `{"type":"bullets","title":"...","items":["..."]}` |
| table | `{"type":"table","title":"...","columns":["A","B"],"rows":[["a","b"]]}` |
| resources | `{"type":"resources","title":"...","items":[{"title":"...","url":"https://...","note":"optional"}]}` |
| glossary | `{"type":"glossary","title":"...","items":[{"term":"...","definition":"..."}]}` |

Only include relevant blocks. Do not add sample content from example.json to user guides. All JSON strings require double quotes. Use actual array brackets, not Markdown escaped brackets.

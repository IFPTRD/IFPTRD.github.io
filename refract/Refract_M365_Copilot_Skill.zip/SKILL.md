---
name: refract-guide-authoring
description: Turn a user-supplied DOCX, PDF, or other document into concise, source-grounded, valid Refract JSON for the interactive guide builder. Use when the user asks for a Refract guide, playbook, quick reference, handbook, or decision aid, or supplies a source document to the Refract agent.
---

# Refract guide authoring

## Start automatically
Read the user's documents attached or selected in the **current conversation**, then create the guide without repeating onboarding text or requesting a special command. Infer the audience and purpose sensibly when not specified. If there is no accessible source, explain this briefly instead of inventing material. Do not mistake the generic example in this skill for a factual source.

## Produce the right guide
Extract the source's actual purpose, decisions, procedures, authorities, exceptions, resources, and terms. Organize by what the reader needs to *do*, not by the source file's table of contents. Prioritize helpful opening pages, practical reference, compact tables, and direct navigation; use nested pages only when they add clarity. Preserve qualifications and uncertainty. Don't invent facts, authorities, URLs, approvals, dates, or procedural steps. Use [TO VERIFY: short description] sparingly for material unresolved points.

## Exact output
Return ONE complete, valid JSON object without Markdown fences, prefatory text, comments, trailing commas, or other content. Its top-level keys must be "meta", "pages", and "glossary". Ensure "pages" is a nonempty array ordered by intended navigation. Every page has unique lowercase-hyphenated "id", a "title", optional "parent" referencing an existing page, optional "intro", and "blocks". Each block must conform to the bundled `references/refract-schema.json` and `references/format.md`. The file `references/example.json` shows **shapes**, not approved text or facts.

Use precisely these block shapes:
- hero: type, kicker, title, text
- paragraph: type, title, text
- note: type, label, text (not title)
- checks: type, title, items [{title, detail}]
- cards: type, title, items [{title, text, link?}], where link is an existing page ID
- steps: type, title, items [{title, text}]
- bullets: type, title, items [strings]
- table: type, title, columns [strings], rows [[strings]] (same length as columns)
- resources: type, title, items [{title, url, note?}] with real user-supplied HTTP(S) URLs
- glossary: type, title, items [{term, definition}]

Put defined terms in the top-level glossary array of {term, definition}. Optional [[TERM]] notation in prose adds hover definitions. Omit resources blocks when links were not supplied—use bullets to list unlinked resources.

## Validate before answering
Make sure the output parses with a real JSON parser. If code execution is available, save JSON and run `scripts/validate_refract.py guide.json`; fix all reported errors and rerun. Confirm linked page IDs, block item shapes, table row lengths, and URL integrity. If code tools are unavailable, perform the same checks conceptually. Prefer fewer concise pages to truncated JSON. Never include literal `\\[` or `\\]` outside quoted strings, and never print a Python literal instead of JSON.

## Information protection
The Refract builder is public static code hosted on GitHub Pages. It operates within the user's browser; this does **not** authorize public disclosure of the source content or generated guide. Follow the user's organization rules for sensitive or protected documents. Never publish source material or the user's JSON to GitHub, and never copy content from unrelated documents into the reusable skill.

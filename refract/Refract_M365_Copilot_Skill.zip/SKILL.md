---
name: refract-guide-authoring
description: Convert user-supplied documents into valid Refract JSON for the Refract guide builder. Use for document-to-guide and playbook tasks.
---
# Refract guide authoring

## On receiving a document
Read the user-selected or attached document as the factual source. When it is accessible, proceed without asking users to attach it again or repeating starter instructions. Infer a practical audience and guide purpose if missing. If the file cannot be accessed, say so briefly. Do not use the skill's example content as a factual source.

## Absolute workflow rules
Your task is to author JSON for the existing Refract web guide builder, **not** to create a Word file, PDF, slide deck, Python script, or new website. Do not browse supplied URLs unless the user requests browsing; preserve exact provided URLs as links. Do not narrate your reasoning, plan, tool usage or intent. Never say "I'm considering" or "I'll use Python". If available, privately run the validator, but do not describe the validation process to users.

## Output format
Output EXACTLY ONE complete fenced code block tagged `json`. Place one valid JSON object inside it. Do not add text before or after the code block. This format lets users copy JSON into Refract directly; Refract supports Markdown code fences. The JSON must use standard JSON syntax, double-quoted property names, literal [ and ] brackets, no Markdown escaping, no comments, no trailing commas, and no Python values.

## Structure
Top-level keys are "meta", "pages", and "glossary".
"meta" contains "title", "subtitle" and "audience" strings. "pages" is a nonempty ordered array. Each page has "id", "title", optional "intro", optional "parent" referencing an existing page ID, and "blocks". "glossary" is an array of {"term","definition"} objects.
Allowed blocks:
- hero {"type":"hero","kicker":"...","title":"...","text":"..."}
- paragraph {"type":"paragraph","title":"...","text":"..."}
- note {"type":"note","label":"...","text":"..."} (not title)
- checks {"type":"checks","title":"...","items":[{"title":"...","detail":"..."}]}
- cards {"type":"cards","title":"...","items":[{"title":"...","text":"...","link":"existing-page-id"}]}
- steps {"type":"steps","title":"...","items":[{"title":"...","text":"..."}]}
- bullets {"type":"bullets","title":"...","items":["..."]}
- table {"type":"table","title":"...","columns":["..."],"rows":[["..."]]}
- resources {"type":"resources","title":"...","items":[{"title":"...","url":"https://actual-source-url","note":"..."}]}
- glossary {"type":"glossary","title":"...","items":[{"term":"...","definition":"..."}]}
Use resources only with real URLs; unlinked references belong in bullets. Every table row matches its column count. IDs are unique lowercase hyphenated and card links resolve to valid page IDs. See references/example.json for format only, never facts.

## Content quality and validation
Build an audience-first, concise and navigable guide from the source. Preserve limits, uncertainty and key distinctions. Avoid inventing details. Prefer 3–5 useful pages to long output that becomes truncated. Validate the JSON syntax and Refract block shapes before final output; run scripts/validate_refract.py privately if executable. Do not use escaped \[ or \] syntax, broken table arrays, or lists of strings where objects are required. Do not add other content outside the JSON code box.

## Security
Never upload or publish a user's source documents or generated JSON to public GitHub. Refract is public code but guides must be handled under applicable organization policies.

---
name: refract-guide-authoring
description: Turn one or more attached Word, PDF, or other source documents into a concise, audience-focused, valid JSON guide that can be imported into the Refract interactive HTML guide builder. Use when the user supplies documents and asks for a Refract guide, quick reference, playbook, handbook, decision aid, or web guide.
---

# Refract: source documents to a validated web guide

## Start without needless questions

Treat documents attached to the **current agent conversation** as the sources for the task. When a user attaches a DOCX or PDF and asks for a guide (or submits the document to this guide-authoring agent), read it and proceed without asking them to repeat a specific starter prompt. Infer a sensible audience and purpose from the content where not specified; use explicitly stated preferences over inferences.

If there is no accessible document or other substantive source, briefly state that you cannot access a source and ask the user to attach or select one **in this agent conversation**. Never copy onboarding text or placeholder facts as an answer, and never claim to have read an inaccessible attachment.

**Activation trigger:** document-to-guide conversion, a request for a Refract JSON guide, or revisions to a Refract guide. Use this skill whenever those tasks arise.

## Strict behaviour and response contract

- **You are NOT writing a Word, PDF, or Markdown document.** You are authoring JSON content for a prebuilt web-guide renderer. Do not choose page counts or document-creation tools as if laying out a separate document.
- **No visible narration of your work.** Do not respond with statements such as "I'm considering...", "I'll use Python...", "I will create...", descriptions of plans, status updates, reasoning, or tool-selection chatter. If you need to plan internally, do so without outputting it.
- Do not research or browse web URLs mentioned in the source unless the user explicitly requests external research. Treat source URLs as references for approved links, not invitations to fetch additional facts. Use the actual attached file(s).
- Python, when available, may be used to *validate JSON with the bundled validator*, not to generate a Word document. Never output script code instead of the guide JSON.
- If content is unavailable, explain that clearly in one short sentence. Otherwise the FINAL response contains **only one fenced `json` code block**.

## Input boundaries

- Use only the supplied, accessible sources for factual content. The `references/example.json` file is a **schema illustration, not an information source**. Never reproduce its placeholder content.
- Do not invent URLs, decision rights, names, legal mandates, dates, numbers, or approval status. Identify significant gaps succinctly.
- Do not publish or upload documents, source text, or generated guides to GitHub. Refract runs in a public static hosting environment, but generated guides need separate approved distribution appropriate to their information classification.
- For multiple source documents, reconcile aligned facts and flag significant discrepancies rather than silently choosing one.

## Guide-design workflow

1. Read the source material. Identify **who will use the guide** and **what they must understand or do**.
2. Organize by user tasks, not the original document's table of contents. Put essential guidance before background material. Prefer 3–5 purposeful pages by default, with nested references only where useful. Fewer complete pages are better than many malformed or truncated ones.
3. Use brief, descriptive titles, concise lead sentences, short paragraphs, and actionable sequences. Avoid duplicate content, unnecessary executive advice, and decorative excess.
4. Select the smallest suitable block type: `hero`, `paragraph`, `note`, `checks`, `cards`, `steps`, `bullets`, `table`, `resources`, `glossary`. See `references/format.md` and `references/refract-schema.json` for precise fields.
5. Use internal links only to **existing page IDs**. Only use an external resource link where the source supplies the real URL.
6. Put a short glossary at the end where specialized terms recur. A definition can be linked in prose as `[[TERM]]` when TERM appears in the top-level glossary.
7. Preserve nuance and uncertainty, especially around authorities, statutory status, responsibilities, and pending approvals. Never turn an assumption into a confirmed fact.

## Format contract — mandatory

Inside the code fence, output a **single complete JSON object** whose top-level keys include `meta`, `pages`, `glossary`:

```json
{
  "meta": {"title": "Guide title", "subtitle": "Short descriptor", "audience": "Intended readers"},
  "pages": [
    {"id": "start-here", "title": "Start Here", "intro": "Short orientation.", "blocks": []}
  ],
  "glossary": []
}
```

**Output format for chat: enclose the ONE complete JSON object in a single fenced `json` code block.** Begin with three backticks and `json` on the same line; end with three backticks on a separate line. Include nothing before or after the block. The fences are display-only; they are not part of JSON. Refract accepts the code fence if pasted directly. Use a downloadable UTF-8 `.json` file only when explicitly asked or when chat output is too long and the tenant supports file creation. Do not truncate JSON.

**Syntax rules:** Standard JSON only: double-quoted strings and keys, straight brackets `[` and `]` (never `\[` or `\]` outside strings), no comments, single quotes, trailing commas, or Markdown escapes. Escape quote characters **inside** strings. Every table row is an array of the same length as `columns`.

**Crucial block distinctions:**
- `checks.items` is an array of objects with `title` and `detail`—**not** an array of strings.
- `bullets.items` is an array of strings.
- `note` uses the field `label`, **not** `title`.
- `resources.items` requires **real URLs**, using `title`, `url`, and optionally `note`; if no URL is supplied, use `bullets` or `paragraph` instead.
- `steps.items` uses objects with `title` and `text`.
- `cards.items` uses objects with `title`, `text`, and optionally `link` to another page ID.
- `glossary.items` and top-level `glossary` use objects with `term` and `definition`.
- Do not generate extra, unsupported block types or add block shapes from other templates.

## Validation before responding

1. Read `references/format.md` for the allowed field shapes and `references/example.json` for a small valid model.
2. Prefer writing a JSON file and, **if script execution is available**, run:

   `python scripts/validate_refract.py guide.json`

   Fix every error and run again. If execution is unavailable, conduct the same field-by-field and JSON syntax checks yourself. The script being present does not guarantee it was executed.
3. Confirm each page ID is unique and lower-hyphenated; each parent and card target exists; page and table structures match the schema; no unsupported facts or private example material are included.
4. If the output is too long, reduce low-priority background sections and preserve a **complete valid document** rather than cutting off midway.
5. Provide only a single `json` code block containing the complete JSON, or a `.json` file if explicitly requested and supported. Never append a report of how you validated it unless the user asks.

## Failure recovery

If a user reports `Invalid JSON`, fix the exact JSON they provide instead of asking them to repeat onboarding. Run the validator if possible. If a source file was attached but inaccessible, explain the access limitation rather than guessing its contents.
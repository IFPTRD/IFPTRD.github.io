#!/usr/bin/env python3
"""Check Refract JSON with the Python standard library. Run: python validate_refract.py file.json"""
import json, re, sys
def run(path):
 try:
  with open(path,encoding="utf-8") as f:d=json.load(f)
 except (OSError,json.JSONDecodeError) as e:print("ERROR JSON:",e);return 1
 errors=[]
 def chk(cond,msg):
  if not cond:errors.append(msg)
 chk(isinstance(d,dict),"root must be an object")
 if not isinstance(d,dict):return 1
 chk(isinstance(d.get("meta"),dict) and isinstance(d.get("meta",{}).get("title"),str),"meta.title missing")
 ps=d.get("pages")
 chk(isinstance(ps,list) and bool(ps),"pages must be nonempty array")
 if not isinstance(ps,list):return 1
 ids=set()
 for i,p in enumerate(ps,1):
  if not isinstance(p,dict):errors.append(f"page {i} must be object");continue
  pid=p.get("id")
  chk(isinstance(pid,str) and bool(re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*",pid)),f"page {i}: invalid id")
  chk(pid not in ids,f"page {i}: duplicate id")
  ids.add(pid)
  chk(isinstance(p.get("title"),str),f"page {i}: title missing")
  bs=p.get("blocks")
  chk(isinstance(bs,list),f"page {i}: blocks not array")
  for j,b in enumerate(bs if isinstance(bs,list) else [],1):
   at=f"page {i}, block {j}"
   if not isinstance(b,dict):errors.append(at+": not object");continue
   typ=b.get("type")
   chk(typ in ("hero","paragraph","note","checks","cards","steps","bullets","table","resources","glossary"),at+": invalid type")
   if typ=="note":chk(isinstance(b.get("label"),str) and isinstance(b.get("text"),str),at+": note requires label/text")
   elif typ is not None:chk(isinstance(b.get("title"),str),at+": title missing")
   if typ=="table":
    cs,rs=b.get("columns"),b.get("rows")
    chk(isinstance(cs,list) and bool(cs) and isinstance(rs,list),at+": columns/rows missing")
    if isinstance(cs,list) and isinstance(rs,list):
     for k,row in enumerate(rs,1):chk(isinstance(row,list) and len(row)==len(cs),at+f": wrong cell count row {k}")
   if typ in ("checks","cards","steps","bullets","resources","glossary"):
    it=b.get("items")
    chk(isinstance(it,list),at+": items must be array")
    for k,x in enumerate(it if isinstance(it,list) else [],1):
     loc=at+f", item {k}"
     if typ=="bullets":chk(isinstance(x,str),loc+": must be string");continue
     if not isinstance(x,dict):errors.append(loc+": needs object");continue
     keys={"checks":["title","detail"],"cards":["title","text"],"steps":["title","text"],"resources":["title","url"],"glossary":["term","definition"]}[typ]
     chk(all(isinstance(x.get(key),str) for key in keys),loc+": invalid fields")
     if typ=="resources" and isinstance(x.get("url"),str):chk(x["url"].startswith(("http://","https://")),loc+": invalid URL")
 for i,p in enumerate(ps,1):
  if not isinstance(p,dict):continue
  chk(not p.get("parent") or p["parent"] in ids,f"page {i}: unknown parent")
  for b in p.get("blocks",[]):
   if isinstance(b,dict) and b.get("type")=="cards":
    for x in b.get("items",[]):
     if isinstance(x,dict):chk(not x.get("link") or x["link"] in ids,f"page {i}: unknown card link")
 for item in errors:print("ERROR:",item)
 if errors:return 1
 print("VALID:",len(ps),"pages");return 0
if __name__=="__main__":
 sys.exit(run(sys.argv[1]) if len(sys.argv)==2 else 2)

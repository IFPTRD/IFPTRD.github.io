# Refract JSON reference
The response must be one fenced `json` code block containing a complete, valid JSON object. Refract strips the code fence automatically when pasted.
Root: `{"meta":{"title":"...","subtitle":"...","audience":"..."},"pages":[...],"glossary":[]}`.
Pages are ordered for navigation. Each page needs `id`, `title`, and `blocks`, with optional `intro` and `parent`.
Allowed blocks and required fields:
- hero: {type, kicker, title, text}
- paragraph: {type, title, text}
- note: {type, label, text} (NOT note.title)
- checks: {type, title, items:[{title, detail}]} (NOT a string array)
- cards: {type, title, items:[{title, text, link?}]}; link must be an existing page id
- steps: {type, title, items:[{title, text}]}
- bullets: {type, title, items:[strings]}
- table: {type, title, columns:[strings], rows:[[strings]]}; row lengths equal columns
- resources: {type, title, items:[{title, url, note?}]}; use only real supplied HTTP(S) URLs
- glossary: {type, title, items:[{term, definition}]}
Top-level glossary is [{term, definition}], never a map.
For unlinked plans or documents, use a bullets block instead of resources.
Never use Markdown-escaped bracket syntax such as `\\[` or `\\]` outside strings. JSON uses standard double quotes and brackets.
Use `scripts/validate_refract.py` only to validate the JSON; it is NOT a document-generation tool.

# Refract guide JSON format v2

The **intermediate JSON** is not the intended user-facing output. The HTML renderer converts it into a standalone, editable guide.

Root: `{"meta":{"title":"Guide title","subtitle":"Short subtitle","audience":"Intended reader"},"pages":[...],"glossary":[]}`.

Each page: `{"id":"unique-kebab-case","title":"Page Title","intro":"Concise purpose","parent":"optional-parent-id","blocks":[...]}`. Parent links and card destination links must reference existing page IDs. Page order sets sidebar and print order.

Block fields:
- `hero`: `type,kicker?,title,text` (short, high-value orientation only).
- `paragraph`: `type,title,text`.
- `note`: `type,label,text` (NOT `title`).
- `checks`: `type,title,items:[{title,detail}]` (NOT strings).
- `cards`: `type,title,items:[{title,text,link?}]` (link must target a page ID).
- `steps`: `type,title,items:[{title,text}]`.
- `bullets`: `type,title,items:[string]`.
- `table`: `type,title,columns:[string],rows:[[string]]` (equal cell counts).
- `resources`: `type,title,items:[{title,url,note?}]` with real supplied HTTP(S) URLs.
- `glossary`: `type,title,items:[{term,definition}]`.
- `governance`: `type,title,intro?,columns:[{title,text?,items:[{title,text?}]}],caption?` (2–4 columns, ideally three).
- `timeline`: `type,title,items:[{period,title,text}]`.

Top-level glossary: `[{"term":"TERM","definition":"Meaning"}]`. Use `[[TERM]]` in text for hover/focus definitions.

Special cases: use `bullets` to list unlinked resources, not `resources`. Do not include source provenance. All text is plain text, not HTML. Never invent URLs, authorities, organizations or source visuals.

The generated HTML must contain a `script#guide-data` JSON payload and HTML format version marker. Refract Studio supports exact import of this structured data when its validator recognizes the block types.

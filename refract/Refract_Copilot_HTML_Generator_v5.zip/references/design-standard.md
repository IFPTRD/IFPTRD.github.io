# Refract design and usability standard

The finished guide should feel like a carefully designed decision and reference tool, not a converted document or a collection of cards.

## Interface
- Light, quiet header with guide title/subtitle; compact search and printer icon.
- Clear left navigation with short, Title Case section labels and subdued nested pages, selected state; first page must be the most useful entry point.
- Comfortable reading width, restrained navy/teal palette, strong contrast, consistent rhythm. Avoid oversized hero cards and redundant page titles.
- Numbered 2-column executive checks should read down the first column, then the second, collapsing to one column on mobile.
- Cards are primarily for actionable navigation and distinct concepts; tables for genuine comparison and authority/role matrices.
- Glossary definitions are available via hover/focus; search should prioritize matching glossary terms.
- Named Previous/Next navigation at the bottom of each page; no duplicated top "back" links.

## Specialty visual layouts
- `governance` is for a source-supported multi-tier, multi-stakeholder model. Render as parallel columns containing actor/authority nodes; distinguish coordination from decision rights in language. Use captions to indicate proposed, confirmed or illustrative status. Do not invent names or connections.
- `timeline` shows real source-supported sequence or simulated periods. Do not invent dates/injects or imply a future event is confirmed.
- If a particular chart, seating arrangement or diagram must be reproduced EXACTLY, do not redraw it from imagination; require the original image/asset or include an explicit placeholder. The generic schema cannot fabricate source visuals faithfully.

## Editorial quality
- Use task-oriented headings: "Your Role", "Decision Aid", "Governance", "Escalation", not multiple "Context" or "Considerations" headings.
- Keep primary pages selective. Put extensive legislation, care-continuum detail, technical plans and acronyms into nested references only when relevant.
- Keep essential content and qualifications; remove repetitive generic advice. Do not substitute generic process steps for the actual documented model or decisions.
- Clearly distinguish approved, proposed, and exercised/testing structures.
- Do not automatically include source file names, document classification, "Based on" statements, or internal/public distribution boilerplate.

## Responsive and print
- Main content never horizontally clips on common desktop and mobile widths.
- On small screens, provide usable, readable navigation and stack multi-column cards/diagrams.
- Print must include all pages, keep headings with following blocks, repeat table headers, avoid empty pages, suppress navigation controls, and preserve legibility of diagrams.
- Export must remain a self-contained HTML document with embedded JSON for Refract Studio round-trip editing.

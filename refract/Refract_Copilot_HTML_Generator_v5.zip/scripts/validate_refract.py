#!/usr/bin/env python3
"""Validate Refract JSON structure and flag common authoring problems (standard library only)."""
import argparse
import collections
import json
import re
import sys
from pathlib import Path

ALLOWED={'hero','paragraph','note','checks','cards','steps','bullets','table','resources','glossary','governance','timeline'}

def check(data):
    errors, warnings=[],[]
    def err(where,msg): errors.append(f'{where}: {msg}')
    def text(v):return isinstance(v,str) and bool(v.strip())
    if not isinstance(data,dict):return ['Root must be a JSON object'],warnings
    if not isinstance(data.get('meta'),dict) or not text(data['meta'].get('title')):err('meta','nonempty title required')
    for k in ('source','sources','provenance','filename','classification','disclaimer'):
        if k in data.get('meta',{}): warnings.append(f'meta.{k}: generated production metadata should not be shown')
    pages=data.get('pages')
    if not isinstance(pages,list) or not pages:return errors+['pages must be a nonempty array'],warnings
    ids=set();heads=collections.Counter();block_count=0
    for pi,p in enumerate(pages):
        path=f'pages[{pi}]'
        if not isinstance(p,dict):err(path,'must be an object');continue
        pid=p.get('id')
        if not isinstance(pid,str) or not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',pid):err(path+'.id','must be lower-hyphenated')
        elif pid in ids:err(path+'.id','duplicate ID')
        else:ids.add(pid)
        if not text(p.get('title')):err(path+'.title','required')
        blocks=p.get('blocks')
        if not isinstance(blocks,list):err(path+'.blocks','must be an array');continue
        if len(blocks)>14:warnings.append(f'{path}: overloaded page ({len(blocks)} blocks); consider splitting')
        block_count+=len(blocks)
        for bi,b in enumerate(blocks):
            loc=f'{path}.blocks[{bi}]'
            if not isinstance(b,dict):err(loc,'must be object');continue
            kind=b.get('type')
            if kind not in ALLOWED:err(loc+'.type','unsupported block');continue
            title=b.get('label') if kind=='note' else b.get('title')
            if not text(title):err(loc,'requires '+('label' if kind=='note' else 'title'))
            elif kind!='note':heads[title.strip().lower()]+=1
            if kind in ('hero','paragraph','note') and not text(b.get('text')):err(loc,'text required')
            items=b.get('items')
            if kind in ('cards','checks','steps','bullets','resources','glossary','timeline'):
                if not isinstance(items,list):err(loc+'.items','array required');continue
                if len(items)==1 and kind=='bullets':warnings.append(loc+': one-item bullets usually belong in a paragraph or grouped list')
                keys={'cards':('title','text'),'checks':('title','detail'),'steps':('title','text'),'resources':('title','url'),'glossary':('term','definition'),'timeline':('period','title','text')}
                for ii,item in enumerate(items):
                    sub=f'{loc}.items[{ii}]'
                    if kind=='bullets':
                        if not text(item):err(sub,'must be nonempty string')
                    elif not isinstance(item,dict):err(sub,'must be object')
                    else:
                        for k in keys[kind]:
                            if not text(item.get(k)):err(sub+'.'+k,'required string')
                        if kind=='resources' and text(item.get('url')) and not re.match(r'^https?://',item['url'],re.I):err(sub,'HTTP(S) URL required')
            if kind=='table':
                cols,rows=b.get('columns'),b.get('rows')
                if not isinstance(cols,list) or not cols or not all(text(v) for v in cols):err(loc+'.columns','nonempty column labels required')
                if not isinstance(rows,list):err(loc+'.rows','array required')
                elif isinstance(cols,list):
                    for ri,row in enumerate(rows):
                        if not isinstance(row,list) or len(row)!=len(cols) or not all(isinstance(x,str) for x in row):err(loc+f'.rows[{ri}]','cell count/type mismatch')
                if isinstance(rows,list) and len(rows)>18:warnings.append(loc+': lengthy table; consider nested reference pages')
            if kind=='governance':
                lanes=b.get('columns')
                if not isinstance(lanes,list) or not 2<=len(lanes)<=4:err(loc+'.columns','2–4 governance columns required')
                else:
                    for ci,col in enumerate(lanes):
                        at=f'{loc}.columns[{ci}]'
                        if not isinstance(col,dict) or not text(col.get('title')):err(at,'title required');continue
                        if not isinstance(col.get('items'),list) or not col['items']:err(at+'.items','nonempty array required');continue
                        for j,entry in enumerate(col['items']):
                            if not isinstance(entry,dict) or not text(entry.get('title')):err(at+f'.items[{j}]','title required')
    for i,p in enumerate(pages):
        if not isinstance(p,dict):continue
        if p.get('parent') and p['parent'] not in ids:err(f'pages[{i}].parent','unknown page')
        for j,b in enumerate(p.get('blocks',[])):
            if isinstance(b,dict) and b.get('type')=='cards':
                for k,item in enumerate(b.get('items',[])):
                    if isinstance(item,dict) and item.get('link') and item['link'] not in ids:err(f'pages[{i}].blocks[{j}].items[{k}].link','unknown page')
    for key,count in heads.items():
        if (key in {'context','considerations','quick reference','overview','related resources'} and count>=3):
            warnings.append(f'repeated generic heading "{key}" ({count} uses); consolidate and rename')
    if not isinstance(data.get('glossary',[]),list):err('glossary','must be array')
    provenance=re.compile(r'^(?:sources?|source and distribution|document provenance|generated from|based on|about this guide)$',re.I)
    for i,p in enumerate(pages):
        if not isinstance(p,dict):continue
        if provenance.match(str(p.get('title',''))):warnings.append(f'pages[{i}]: unwanted generated source attribution')
        for j,b in enumerate(p.get('blocks',[])):
            if not isinstance(b,dict):continue
            if provenance.match(str(b.get('title',b.get('label','')))) or re.search(r'\bbased on [^\n]{0,140}\.(?:docx|pdf)\b',str(b.get('text','')),re.I):
                warnings.append(f'pages[{i}].blocks[{j}]: source/provenance boilerplate')
    return errors,warnings

def main():
    p=argparse.ArgumentParser();p.add_argument('file',type=Path);p.add_argument('--fail-on-warnings',action='store_true');a=p.parse_args()
    try:d=json.loads(a.file.read_text('utf-8-sig'))
    except (OSError,json.JSONDecodeError) as e:print('INVALID JSON:',e,file=sys.stderr);return 2
    errs,warns=check(d)
    for warn in warns:print('WARNING:',warn,file=sys.stderr)
    for err in errs:print('ERROR:',err,file=sys.stderr)
    if errs or (warns and a.fail_on_warnings):return 1
    print('VALID:',len(d['pages']),'pages');return 0
if __name__=='__main__':sys.exit(main())

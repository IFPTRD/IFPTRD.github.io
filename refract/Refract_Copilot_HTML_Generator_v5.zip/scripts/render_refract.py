#!/usr/bin/env python3
"""Render a Refract guide as one self-contained, Studio-editable HTML file."""
import argparse,json,sys
from pathlib import Path
from validate_refract import check
ROOT=Path(__file__).resolve().parent.parent
TEMPLATE=ROOT/'references'/'guide-template.html'
def render(data,template_path=TEMPLATE):
    html=template_path.read_text(encoding='utf-8-sig')
    for token in ('__DATA_JSON__','__EDITOR_MODE__','__EDITOR_PAGE__'):
        if html.count(token)!=1:raise ValueError('Template must contain one '+token)
    if 'id="guide-data"' not in html:raise ValueError('Guide-data script missing')
    html=html.replace('__EDITOR_MODE__','false').replace('__EDITOR_PAGE__','null')
    safe=json.dumps(data,separators=(',',':'),ensure_ascii=False)
    safe=safe.replace('<',r'\u003c').replace('&',r'\u0026').replace('\u2028',r'\u2028').replace('\u2029',r'\u2029')
    return html.replace('__DATA_JSON__',safe)
def main():
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--fail-on-warnings',action='store_true');a=p.parse_args()
    try:data=json.loads(a.source.read_text('utf-8-sig'))
    except (OSError,json.JSONDecodeError) as e:print('Invalid JSON:',e,file=sys.stderr);return 2
    errors,warnings=check(data)
    for w in warnings:print('WARNING:',w,file=sys.stderr)
    for e in errors:print('ERROR:',e,file=sys.stderr)
    if errors or (warnings and a.fail_on_warnings):return 1
    try:
        if a.output.resolve() in {a.source.resolve(),TEMPLATE.resolve()}:raise ValueError('Output must not overwrite source/template')
        out=render(data);a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(out,encoding='utf8')
    except (OSError,ValueError) as e:print('Render failed:',e,file=sys.stderr);return 3
    print('CREATED:',a.output,len(data['pages']),'pages');return 0
if __name__=='__main__':sys.exit(main())
